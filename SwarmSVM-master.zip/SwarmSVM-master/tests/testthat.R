library(testthat)
library(SwarmSVM)

test_check("SwarmSVM")
