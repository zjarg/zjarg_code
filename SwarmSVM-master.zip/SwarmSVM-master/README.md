# SwarmSVM

[![Build Status](https://travis-ci.org/hetong007/SwarmSVM.png)](https://travis-ci.org/hetong007/SwarmSVM)
[![Coverage Status](https://coveralls.io/repos/hetong007/SwarmSVM/badge.svg?branch=master&service=github)](https://coveralls.io/github/hetong007/SwarmSVM?branch=master)
[![CRAN Downloads](http://cranlogs.r-pkg.org/badges/SwarmSVM)](https://cran.r-project.org/package=SwarmSVM)

The repository is an R package about ensemble learning algorithms based on SVM for my Google Summer of Code 2015 project.

It is under development.

### Installation

```r
devtools::install_github('hetong007/SwarmSVM')
```

Now it is on CRAN, you can also install it by

```r
install.packages('SwarmSVM')
```

