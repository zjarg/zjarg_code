#' @importClassesFrom SparseM matrix.csr
#' @importFrom SparseM t
#' @import e1071
#' @import kernlab
#' @import Matrix
#' @import LiblineaR
#' @import methods
#' @import checkmate
#' @importFrom BBmisc suppressAll
#' @useDynLib SwarmSVM, .registration = TRUE
NULL
